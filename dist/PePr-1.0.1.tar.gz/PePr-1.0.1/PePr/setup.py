from distutils.core import setup

setup(name="PePr",
      version="1.1"
      description="Peak-calling and Prioritization pipeline for ChIP-Seq data",
      author="Yanxiao Zhang",
      author_email="yanxiazh@umich.edu",
#      url=""
      packages=["PePr"]
      install_requires=[
          'numpy',
          'scipy',
          ]
      )



